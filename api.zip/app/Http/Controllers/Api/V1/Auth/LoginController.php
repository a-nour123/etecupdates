<?php

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Api\V1\BaseApiController;
use App\Http\Requests\Api\V1\Auth\LoginRequest;
use App\Http\Resources\Api\V1\LoginResource;
use App\Services\Api\Auth\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\ValidationException;

/**
 * API Login controller.
 */
class LoginController extends BaseApiController
{
    public function __construct(
        protected AuthService $authService
    ) {}

    /**
     * Login and return user with token.
     *
     * @param  LoginRequest  $request
     * @return JsonResponse
     */
    public function __invoke(LoginRequest $request): JsonResponse
    {
        try {
            $validated = $request->validated();
            
            $result = $this->authService->login(
                $validated['username'],
                $validated['password'],
                $validated['device_name'] ?? null
            );

            return $this->success(
                new LoginResource($result),
                __('auth.login_success') ?: 'Login successful.',
                200
            );
        } catch (ValidationException $e) {
            return $this->validationError(
                $e->errors(),
                $e->getMessage()
            );
        }
    }
}
