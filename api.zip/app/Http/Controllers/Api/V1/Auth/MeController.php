<?php

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Api\V1\BaseApiController;
use App\Http\Resources\Api\V1\UserResource;
use App\Services\Api\Auth\AuthService;
use Illuminate\Http\JsonResponse;

/**
 * API current user (me) controller.
 */
class MeController extends BaseApiController
{
    public function __construct(
        protected AuthService $authService
    ) {}

    /**
     * Get authenticated user.
     *
     * @return JsonResponse
     */
    public function __invoke(): JsonResponse
    {
        $user = $this->authService->user();

        if (!$user) {
            return $this->unauthorized();
        }

        return $this->success(new UserResource($user->load('role')), 'Success.');
    }
}
