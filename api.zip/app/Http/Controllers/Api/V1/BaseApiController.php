<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Traits\Api\ApiResponseTrait;

/**
 * Base controller for API v1. All API controllers should extend this.
 */
abstract class BaseApiController extends Controller
{
    use ApiResponseTrait;
}
