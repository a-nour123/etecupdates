<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Requests\Api\V1\StoreExceptionRequest;
use App\Http\Resources\Api\V1\ExceptionResource;
use App\Services\Api\ExceptionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

/**
 * API controller to handle exceptions.
 */
class ExceptionController extends BaseApiController
{
    public function __construct(
        protected ExceptionService $exceptionService
    ) {}

    /**
     * Store a new exception.
     *
     * @param  StoreExceptionRequest  $request
     * @return JsonResponse
     */
    public function store(StoreExceptionRequest $request): JsonResponse
    {
        $validated = $request->validated();
        
        // Get authenticated user ID
        $exceptionCreatorId = Auth::id();
        
        if (!$exceptionCreatorId) {
            return $this->error('User not authenticated.', 401);
        }

        try {
            $exception = $this->exceptionService->createException($validated, $exceptionCreatorId);
            
            return $this->success(
                new ExceptionResource($exception),
                'Exception created successfully.',
                201
            );
        } catch (\Exception $e) {
            return $this->error('Failed to create exception: ' . $e->getMessage(), 500);
        }
    }
}
