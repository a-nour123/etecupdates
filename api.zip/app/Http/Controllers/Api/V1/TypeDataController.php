<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Requests\Api\V1\GetTypeDataRequest;
use App\Http\Resources\Api\V1\ControlResource;
use App\Http\Resources\Api\V1\PolicyResource;
use App\Http\Resources\Api\V1\RiskResource;
use App\Services\Api\TypeDataService;
use Illuminate\Http\JsonResponse;

/**
 * API controller to get data by type (policy, control, risk).
 */
class TypeDataController extends BaseApiController
{
    public function __construct(
        protected TypeDataService $typeDataService
    ) {}

    /**
     * Get data based on type parameter.
     *
     * @param  GetTypeDataRequest  $request
     * @return JsonResponse
     */
    public function __invoke(GetTypeDataRequest $request): JsonResponse
    {
        $validated = $request->validated();
        $type = $validated['type'];
        $data = $this->typeDataService->getDataByType($type);

        // Transform based on type
        $resourceClass = match ($type) {
            'policy' => PolicyResource::class,
            'control' => null, // Handle controls differently (array format)
            'risk' => RiskResource::class,
            default => null,
        };

        if ($type === 'control') {
            // Controls are already in array format from service
            return $this->success($data->values()->all(), 'Controls retrieved successfully.');
        }

        // Use resource collection for policy and risk
        if ($resourceClass) {
            $collection = $resourceClass::collection($data);
            return $this->success($collection, ucfirst($type) . ' data retrieved successfully.');
        }

        return $this->success($data, 'Data retrieved successfully.');
    }
}
