<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Resources\Api\V1\UserResource;
use App\Models\User;
use Illuminate\Http\JsonResponse;

/**
 * API controller to get users list.
 */
class UsersController extends BaseApiController
{
    /**
     * Get all users.
     *
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $users = User::select('id', 'name', 'email', 'username')
            ->orderBy('id')
            ->get();

        return $this->success(
            UserResource::collection($users),
            'Users retrieved successfully.'
        );
    }
}
