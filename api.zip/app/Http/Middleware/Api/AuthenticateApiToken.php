<?php

namespace App\Http\Middleware\Api;

use App\Models\ApiToken;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Authenticate API requests using Bearer token from api_tokens table.
 */
class AuthenticateApiToken
{
    public function handle(Request $request, Closure $next)
    {
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated. Token missing.',
            ], 401);
        }

        // Validate JWT token
        $jwtService = app(\App\Services\Api\Jwt\JwtService::class);
        $payload = $jwtService->validateToken($token);

        if (!$payload || !isset($payload['sub'])) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated. Invalid or expired token.',
            ], 401);
        }

        // Get user from token
        $userId = (int) $payload['sub'];
        $user = \App\Models\User::find($userId);

        if (!$user || !$user->enabled || $user->lockout) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated. User account is disabled or locked.',
            ], 401);
        }

        // Check if token was revoked (optional - check database)
        $hashedToken = hash('sha256', $token);
        $apiToken = ApiToken::where('user_id', $userId)
            ->where('token', $hashedToken)
            ->first();

        if (!$apiToken || ($apiToken->expires_at && $apiToken->expires_at->isPast())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated. Token has been revoked or expired.',
            ], 401);
        }

        // Update last used
        $apiToken->update(['last_used_at' => now()]);

        Auth::setUser($user);
        $request->setUserResolver(fn () => $user);

        return $next($request);
    }
}
