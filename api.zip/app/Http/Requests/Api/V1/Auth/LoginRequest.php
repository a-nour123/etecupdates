<?php

namespace App\Http\Requests\Api\V1\Auth;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
            'device_name' => ['nullable', 'string', 'max:100'],
        ];
    }

    public function messages()
    {
        return [
            'username.required' => __('validation.required', ['attribute' => 'username']),
            'password.required' => __('validation.required', ['attribute' => 'password']),
        ];
    }
}
