<?php

namespace App\Http\Requests\Api\V1;

use Illuminate\Foundation\Http\FormRequest;

class GetTypeDataRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'type' => ['required', 'string', 'in:policy,control,risk'],
        ];
    }

    public function messages()
    {
        return [
            'type.required' => 'The type parameter is required.',
            'type.in' => 'The type must be one of: policy, control, risk.',
        ];
    }
}
