<?php

namespace App\Http\Requests\Api\V1;

use Illuminate\Foundation\Http\FormRequest;

class StoreExceptionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'exception_status' => ['nullable', 'in:0,1'],
            'request_status' => ['nullable', 'in:0,1,2'],
            'type' => ['required', 'in:policy,control,risk'],
            'policy_id' => ['required_if:type,policy', 'nullable', 'integer', 'exists:documents,id'],
            'control_id' => ['required_if:type,control', 'nullable', 'integer', 'exists:framework_controls,id'],
            'risk_id' => ['required_if:type,risk', 'nullable', 'integer', 'exists:risks,id'],
            'description' => ['nullable', 'string'],
            'justification' => ['nullable', 'string'],
            'stakeholder' => ['nullable', 'array'],
            'request_duration' => ['nullable', 'string'],
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'The name field is required.',
            'type.required' => 'The type field is required.',
            'type.in' => 'The type must be one of: policy, control, risk.',
            'policy_id.required_if' => 'The policy_id field is required when type is policy.',
            'policy_id.exists' => 'The selected policy does not exist.',
            'control_id.required_if' => 'The control_id field is required when type is control.',
            'control_id.exists' => 'The selected control does not exist.',
            'risk_id.required_if' => 'The risk_id field is required when type is risk.',
            'risk_id.exists' => 'The selected risk does not exist.',
        ];
    }
}
