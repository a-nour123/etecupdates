<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ControlResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'control_id' => $this->id,
            'control_number' => $this->control_number,
            'short_name' => $this->short_name,
            'long_name' => $this->long_name,
            'framework_id' => $this->pivot->framework_id ?? null,
            'regulator_id' => $this->pivot->regulator_id ?? null,
        ];
    }
}
