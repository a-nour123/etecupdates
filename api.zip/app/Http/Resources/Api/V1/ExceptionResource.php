<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ExceptionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'exception_status' => $this->exception_status,
            'request_status' => $this->request_status,
            'type' => $this->type,
            'exception_creator' => $this->exception_creator,
            'policy_approver_id' => $this->policy_approver_id,
            'policy_owner_id' => $this->policy_owner_id,
            'control_approver_id' => $this->control_approver_id,
            'control_owner_id' => $this->control_owner_id,
            'risk_approver_id' => $this->risk_approver_id,
            'risk_owner_id' => $this->risk_owner_id,
            'risk_severity' => $this->risk_severity,
            'description' => $this->description,
            'justification' => $this->justification,
            'created_at' => $this->created_at ? $this->created_at->toIso8601String() : null,
            'updated_at' => $this->updated_at ? $this->updated_at->toIso8601String() : null,
        ];
    }
}
