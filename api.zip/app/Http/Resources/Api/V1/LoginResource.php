<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LoginResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $expiresAt = $this->resource['expires_at'] ?? null;
        if ($expiresAt && is_object($expiresAt)) {
            $expiresAt = $expiresAt->toIso8601String();
        }
        
        $token = $this->resource['token'];
        
        return [
            'user' => new UserResource($this->resource['user']),
            'token' => $token,
            'token_type' => 'Bearer',
            'expires_at' => $expiresAt,
        ];
    }
}
