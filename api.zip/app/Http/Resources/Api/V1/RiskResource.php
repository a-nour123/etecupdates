<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RiskResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'risk_id' => $this->id,
            'subject' => $this->subject,
            'reference_id' => $this->reference_id,
            'status' => $this->status,
        ];
    }
}
