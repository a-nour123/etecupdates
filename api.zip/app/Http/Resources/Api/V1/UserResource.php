<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        // For users list endpoint, return only basic fields
        $data = [
            'id' => $this->id,
            'username' => $this->username,
            'name' => $this->name,
            'email' => $this->email,
        ];

        // Include additional fields if role is loaded (for /auth/me endpoint)
        if ($this->relationLoaded('role')) {
            $data['role_id'] = $this->role_id;
            $data['role'] = [
                'id' => $this->role->id,
                'name' => $this->role->name,
            ];
            $data['enabled'] = (bool) $this->enabled;
            $data['last_login'] = $this->last_login ? (is_object($this->last_login) ? $this->last_login->toIso8601String() : $this->last_login) : null;
        }

        return $data;
    }
}
