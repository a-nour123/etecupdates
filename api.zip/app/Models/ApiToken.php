<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ApiToken extends Model
{
    protected $table = 'api_tokens';

    protected $fillable = [
        'user_id',
        'name',
        'token',
        'abilities',
        'expires_at',
    ];

    protected $hidden = [
        'token',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'last_used_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Create a new JWT token for the user.
     *
     * @param  \App\Models\User  $user
     * @param  string  $name
     * @param  int|null  $expirationMinutes
     * @return string JWT token
     */
    public static function createToken(User $user, string $name = 'api', ?int $expirationMinutes = null): string
    {
        $jwtService = app(\App\Services\Api\Jwt\JwtService::class);
        $jwtToken = $jwtService->generateToken($user->id);

        // Store token hash in database for revocation tracking
        $hashedToken = hash('sha256', $jwtToken);

        $expiresAt = $expirationMinutes
            ? now()->addMinutes($expirationMinutes)
            : null;

        static::create([
            'user_id' => $user->id,
            'name' => $name,
            'token' => $hashedToken,
            'abilities' => json_encode(['*']),
            'expires_at' => $expiresAt,
        ]);

        return $jwtToken;
    }

    /**
     * Find token by JWT (validate and lookup user).
     */
    public static function findToken(string $jwtToken): ?self
    {
        $jwtService = app(\App\Services\Api\Jwt\JwtService::class);
        $payload = $jwtService->validateToken($jwtToken);

        if (!$payload || !isset($payload['sub'])) {
            return null;
        }

        $userId = (int) $payload['sub'];
        
        // Find token record (we store hash, but JWT is self-contained)
        // We'll find by user_id and check if token is still valid
        $token = static::where('user_id', $userId)
            ->orderBy('created_at', 'desc')
            ->first();

        if (!$token) {
            return null;
        }

        // Check expiration from database
        if ($token->expires_at && $token->expires_at->isPast()) {
            $token->delete();
            return null;
        }

        // Update last used
        $token->update(['last_used_at' => now()]);
        
        return $token;
    }
}
