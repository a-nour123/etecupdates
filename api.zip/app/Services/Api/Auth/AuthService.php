<?php

namespace App\Services\Api\Auth;

use App\Models\ApiToken;
use App\Models\User;
use App\Services\Api\Jwt\JwtService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

/**
 * API Authentication service – handles login, token creation, and validation.
 */
class AuthService
{
    /**
     * Attempt login and return user with token.
     *
     * @param  string  $username
     * @param  string  $password
     * @param  string|null  $deviceName
     * @return array{user: User, token: string, expires_at: \Carbon\Carbon|null}
     * @throws ValidationException
     */
    public function login(string $username, string $password, ?string $deviceName = null): array
    {
        $user = User::where('username', $username)->first();

        if (!$user || !Hash::check($password, $user->password)) {
            throw ValidationException::withMessages([
                'username' => [__('auth.failed')],
            ]);
        }

        if (!$user->enabled) {
            throw ValidationException::withMessages([
                'username' => [__('auth.locked')],
            ]);
        }

        if ($user->lockout) {
            throw ValidationException::withMessages([
                'username' => [__('auth.locked')],
            ]);
        }

        // Update last login
        $user->update(['last_login' => now()]);

        $expirationMinutes = (int) config('api.token_expiration_minutes', 60 * 24 * 7);
        
        // Create JWT token
        $jwtService = app(JwtService::class);
        $token = $jwtService->generateToken($user->id);
        
        // Store token hash in database for tracking/revocation
        $hashedToken = hash('sha256', $token);
        $expiresAt = $expirationMinutes > 0 ? now()->addMinutes($expirationMinutes) : null;
        
        ApiToken::create([
            'user_id' => $user->id,
            'name' => $deviceName ?? 'api',
            'token' => $hashedToken,
            'abilities' => json_encode(['*']),
            'expires_at' => $expiresAt,
        ]);

        return [
            'user' => $user,
            'token' => $token,
            'expires_at' => $expiresAt,
        ];
    }

    /**
     * Logout (revoke current token).
     */
    public function logout(): void
    {
        $user = Auth::guard('api')->user();
        if ($user && request()->bearerToken()) {
            $jwtToken = request()->bearerToken();
            $apiToken = ApiToken::findToken($jwtToken);
            if ($apiToken) {
                $apiToken->delete();
            }
        }
    }

    /**
     * Get authenticated user for API.
     */
    public function user(): ?User
    {
        return Auth::guard('api')->user();
    }
}
