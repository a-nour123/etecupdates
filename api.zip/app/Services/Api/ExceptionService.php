<?php

namespace App\Services\Api;

use App\Models\Document;
use App\Models\Exception;
use App\Models\ExceptionSetting;
use App\Models\FrameworkControl;
use App\Models\ResidualRiskScoringHistory;
use App\Models\Risk;
use Illuminate\Support\Facades\DB;

/**
 * Service to handle exception creation logic.
 */
class ExceptionService
{
    /**
     * Get risk severity level from risk score.
     *
     * @param  float|null  $severity
     * @return string|null
     */
    protected function getRiskSeverity($severity)
    {
        if ($severity === null) {
            return null;
        }

        if ($severity < 4) {
            return 'low';
        } elseif ($severity < 7) {
            return 'medium';
        } elseif ($severity < 10) {
            return 'high';
        } else {
            return 'very high';
        }
    }

    /**
     * Create a new exception.
     *
     * @param  array  $data
     * @param  int  $exceptionCreatorId
     * @return Exception
     */
    public function createException(array $data, int $exceptionCreatorId): Exception
    {
        $exceptionSettings = ExceptionSetting::first();
        
        // Set defaults
        $exceptionData = [
            'name' => $data['name'],
            'exception_status' => $data['exception_status'] ?? '1',
            'request_status' => $data['request_status'] ?? '0',
            'type' => $data['type'],
            'exception_creator' => $exceptionCreatorId,
            'description' => $data['description'] ?? null,
            'justification' => $data['justification'] ?? null,
            'stakeholder' => isset($data['stakeholder']) ? json_encode($data['stakeholder']) : null,
            'request_duration' => $data['request_duration'] ?? null,
        ];

        // Handle based on type
        if ($data['type'] === 'policy' && isset($data['policy_id'])) {
            $policyOwnerId = Document::where('id', $data['policy_id'])->value('document_owner');
            
            $exceptionData['policy_owner_id'] = $policyOwnerId;
            
            if ($exceptionSettings && $exceptionSettings->policy_approver == '0') {
                $exceptionData['policy_approver_id'] = $policyOwnerId;
            } else {
                $exceptionData['policy_approver_id'] = $exceptionSettings->policy_approver_id ?? null;
            }
        } elseif ($data['type'] === 'control' && isset($data['control_id'])) {
            $controlOwnerId = FrameworkControl::where('id', $data['control_id'])->value('control_owner');
            
            $exceptionData['control_owner_id'] = $controlOwnerId;
            
            if ($exceptionSettings && $exceptionSettings->control_approver == '0') {
                $exceptionData['control_approver_id'] = $controlOwnerId;
            } else {
                $exceptionData['control_approver_id'] = $exceptionSettings->control_approver_id ?? null;
            }
        } elseif ($data['type'] === 'risk' && isset($data['risk_id'])) {
            $risk = Risk::find($data['risk_id']);
            $riskOwnerId = $risk ? $risk->owner_id : null;
            
            $exceptionData['risk_owner_id'] = $riskOwnerId;
            
            // Get risk severity from residual risk scoring history
            $latestSeverity = ResidualRiskScoringHistory::where('risk_id', $data['risk_id'])
                ->orderBy('last_update', 'desc')
                ->value('residual_risk');
            
            $exceptionData['risk_severity'] = $this->getRiskSeverity($latestSeverity);
            
            if ($exceptionSettings && $exceptionSettings->risk_approver == '0') {
                $exceptionData['risk_approver_id'] = $riskOwnerId;
            } else {
                $exceptionData['risk_approver_id'] = $exceptionSettings->risk_approver_id ?? null;
            }
        }

        // Create exception
        $exception = Exception::create($exceptionData);

        // Attach relationships
        if ($data['type'] === 'policy' && isset($data['policy_id'])) {
            DB::table('exception_policy')->insert([
                'exception_id' => $exception->id,
                'policy_id' => $data['policy_id'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } elseif ($data['type'] === 'control' && isset($data['control_id'])) {
            DB::table('control_exception')->insert([
                'exception_id' => $exception->id,
                'control_id' => $data['control_id'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } elseif ($data['type'] === 'risk' && isset($data['risk_id'])) {
            DB::table('exception_risk')->insert([
                'exception_id' => $exception->id,
                'risk_id' => $data['risk_id'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return $exception->fresh();
    }
}
