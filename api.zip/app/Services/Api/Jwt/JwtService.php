<?php

namespace App\Services\Api\Jwt;

use Carbon\Carbon;

/**
 * JWT Token Service - Generate and validate JWT tokens.
 */
class JwtService
{
    protected $secret;
    protected string $algorithm = 'HS256';
    protected int $ttl; // Time to live in minutes

    public function __construct()
    {
        // Use custom JWT secret or fallback to APP_KEY
        $jwtSecret = config('api.jwt_secret');
        $appKey = config('app.key');
        
        // Use custom secret if set, otherwise use APP_KEY
        $secret = $jwtSecret ?: $appKey;
        
        // Remove 'base64:' prefix if present (Laravel 5.5+)
        if (is_string($secret) && strpos($secret, 'base64:') === 0) {
            $secret = base64_decode(substr($secret, 7));
        }
        
        // Ensure we have a valid secret
        if (empty($secret) || !is_string($secret)) {
            throw new \RuntimeException('JWT secret key is not configured. Set API_JWT_SECRET in .env or ensure APP_KEY is set.');
        }
        
        $this->secret = $secret;
        $this->ttl = (int) config('api.token_expiration_minutes', 60 * 24 * 7); // 7 days default
    }

    /**
     * Generate JWT token for user.
     *
     * @param  int  $userId
     * @param  string  $issuer
     * @return string JWT token
     */
    public function generateToken(int $userId, string $issuer = null): string
    {
        $now = Carbon::now()->timestamp;
        $exp = $this->ttl > 0 ? $now + ($this->ttl * 60) : null;
        
        $issuer = $issuer ?? (config('app.url') ?: 'http://127.0.0.1:8000') . '/api/v1/auth/login';

        $header = [
            'typ' => 'JWT',
            'alg' => $this->algorithm,
        ];

        $payload = [
            'iss' => $issuer,
            'iat' => $now,
            'exp' => $exp,
            'nbf' => $now,
            'jti' => \Str::random(16), // JWT ID
            'sub' => (string) $userId, // Subject (user ID)
            'prv' => hash('sha256', $this->secret . $userId), // Private hash for validation
        ];

        return $this->encode($header, $payload);
    }

    /**
     * Validate and decode JWT token.
     *
     * @param  string  $token
     * @return array|null Decoded payload or null if invalid
     */
    public function validateToken(string $token): ?array
    {
        $parts = explode('.', $token);
        
        if (count($parts) !== 3) {
            return null;
        }

        [$headerB64, $payloadB64, $signatureB64] = $parts;

        try {
            $header = json_decode($this->base64UrlDecode($headerB64), true);
            $payload = json_decode($this->base64UrlDecode($payloadB64), true);

            if (!$header || !$payload) {
                return null;
            }

            // Verify signature
            $expectedSignature = $this->sign($headerB64 . '.' . $payloadB64);
            if (!hash_equals($expectedSignature, $signatureB64)) {
                return null;
            }

            // Check expiration
            if (isset($payload['exp']) && $payload['exp'] < Carbon::now()->timestamp) {
                return null;
            }

            // Check not before
            if (isset($payload['nbf']) && $payload['nbf'] > Carbon::now()->timestamp) {
                return null;
            }

            return $payload;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Encode header and payload into JWT.
     */
    protected function encode(array $header, array $payload): string
    {
        $headerB64 = $this->base64UrlEncode(json_encode($header));
        $payloadB64 = $this->base64UrlEncode(json_encode($payload));
        
        $signature = $this->sign($headerB64 . '.' . $payloadB64);
        
        return $headerB64 . '.' . $payloadB64 . '.' . $signature;
    }

    /**
     * Sign the token.
     */
    protected function sign(string $data): string
    {
        $signature = hash_hmac('sha256', $data, $this->secret, true);
        return $this->base64UrlEncode($signature);
    }

    /**
     * Base64 URL encode.
     */
    protected function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64 URL decode.
     */
    protected function base64UrlDecode(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/'));
    }

    /**
     * Get user ID from token payload.
     */
    public function getUserIdFromToken(string $token): ?int
    {
        $payload = $this->validateToken($token);
        return $payload && isset($payload['sub']) ? (int) $payload['sub'] : null;
    }
}
