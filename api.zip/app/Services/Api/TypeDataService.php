<?php

namespace App\Services\Api;

use App\Models\CenterPolicy;
use App\Models\Document;
use App\Models\FrameworkControl;
use App\Models\Risk;
use Illuminate\Support\Facades\DB;

/**
 * Service to fetch data based on type (policy, control, risk).
 */
class TypeDataService
{
    /**
     * Get data based on type.
     *
     * @param  string  $type
     * @return \Illuminate\Database\Eloquent\Collection|array
     */
    public function getDataByType(string $type)
    {
        return match ($type) {
            'policy' => $this->getPolicies(),
            'control' => $this->getControls(),
            'risk' => $this->getRisks(),
            default => [],
        };
    }

    /**
     * Get all documents (policies).
     */
    protected function getPolicies()
    {
        return Document::select('id', 'document_name')
            ->orderBy('id')
            ->get();
    }

    /**
     * Get all controls with their frameworks and regulators.
     * Returns each control-framework-regulator combination.
     */
    protected function getControls()
    {
        // Get controls with their framework mappings and regulator info
        $controls = DB::table('framework_controls as fc')
            ->join('framework_control_mappings as fcm', 'fc.id', '=', 'fcm.framework_control_id')
            ->join('frameworks as f', 'fcm.framework_id', '=', 'f.id')
            ->leftJoin('regulators as r', 'f.regulator_id', '=', 'r.id')
            ->select(
                'fc.id as control_id',
                'fc.control_number',
                'fc.short_name',
                'fc.long_name',
                'f.id as framework_id',
                'f.name as framework_name',
                'f.regulator_id',
                'r.name as regulator_name'
            )
            ->where(function ($query) {
                $query->whereNull('fc.deleted')
                      ->orWhere('fc.deleted', 0);
            })
            ->orderBy('fc.id')
            ->orderBy('f.id')
            ->get();

        // Transform to array format
        return $controls->map(function ($item) {
            return [
                'control_id' => $item->control_id,
                'control_number' => $item->control_number,
                'short_name' => $item->short_name,
                'long_name' => $item->long_name,
                'framework_id' => $item->framework_id,
                'framework_name' => $item->framework_name,
                'regulator_id' => $item->regulator_id,
                'regulator_name' => $item->regulator_name,
            ];
        });
    }

    /**
     * Get all risks.
     */
    protected function getRisks()
    {
        return Risk::select('id', 'subject', 'reference_id', 'status')
            ->orderBy('id')
            ->get();
    }
}
