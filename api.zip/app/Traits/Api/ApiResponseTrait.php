<?php

namespace App\Traits\Api;

use Illuminate\Http\JsonResponse;

/**
 * Standardized API response trait for consistent JSON structure.
 */
trait ApiResponseTrait
{
    /**
     * Success response.
     */
    protected function success(
        $data = null,
        string $message = 'Success',
        int $httpCode = 200
    ): JsonResponse {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
            'meta' => null,
        ], $httpCode);
    }

    /**
     * Error response.
     */
    protected function error(
        string $message = 'An error occurred',
        int $httpCode = 400,
        $errors = null,
        $errorCode = null
    ): JsonResponse {
        $payload = [
            'success' => false,
            'message' => $message,
            'data' => null,
            'errors' => $errors,
        ];
        if ($errorCode !== null) {
            $payload['error_code'] = $errorCode;
        }
        return response()->json($payload, $httpCode);
    }

    /**
     * Unauthorized response (401).
     */
    protected function unauthorized(string $message = 'Unauthorized'): JsonResponse
    {
        return $this->error($message, 401);
    }

    /**
     * Forbidden response (403).
     */
    protected function forbidden(string $message = 'Forbidden'): JsonResponse
    {
        return $this->error($message, 403);
    }

    /**
     * Validation error response (422).
     */
    protected function validationError($errors, string $message = 'Validation failed'): JsonResponse
    {
        return $this->error($message, 422, $errors);
    }

    /**
     * Not found response (404).
     */
    protected function notFound(string $message = 'Resource not found'): JsonResponse
    {
        return $this->error($message, 404);
    }

    /**
     * Server error response (500).
     */
    protected function serverError(string $message = 'Internal server error'): JsonResponse
    {
        return $this->error($message, 500);
    }
}
