<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| API routes are loaded by the RouteServiceProvider with the "api" middleware
| group. Base prefix: /api
|
*/

// Apply JSON middleware to all API routes
Route::middleware('api.json')->group(function () {
    // V1 API (prefix: /api/v1)
    Route::prefix('v1')->name('api.v1.')->group(base_path('routes/api/v1.php'));
});
