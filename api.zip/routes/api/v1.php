<?php

use App\Http\Controllers\Api\V1\Auth\LoginController;
use App\Http\Controllers\Api\V1\Auth\LogoutController;
use App\Http\Controllers\Api\V1\Auth\MeController;
use App\Http\Controllers\Api\V1\ExceptionController;
use App\Http\Controllers\Api\V1\TypeDataController;
use App\Http\Controllers\Api\V1\UsersController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API V1 Routes
|--------------------------------------------------------------------------
|
| Versioned API routes. Prefix: /api/v1
|
*/

// Public routes
Route::post('/auth/login', LoginController::class)->name('auth.login');

// Protected routes (require Bearer token)
Route::middleware('api.auth')->group(function () {
    Route::post('/auth/logout', LogoutController::class)->name('auth.logout');
    Route::get('/auth/me', MeController::class)->name('auth.me');
    
    // Type data endpoint - returns policies, controls, or risks based on type parameter
    Route::get('/type-data', TypeDataController::class)->name('type.data');
    
    // Users endpoint - returns all users
    Route::get('/users', [UsersController::class, 'index'])->name('users.index');
    
    // Exceptions endpoint - create exception
    Route::post('/exceptions', [ExceptionController::class, 'store'])->name('exceptions.store');
});
