<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('mitigations', function (Blueprint $table) {
            $table->string('deadline_date')->change();
        });
    }

    public function down(): void
    {
        Schema::table('mitigations', function (Blueprint $table) {
            $table->date('deadline_date')->change();
        });
    }
};