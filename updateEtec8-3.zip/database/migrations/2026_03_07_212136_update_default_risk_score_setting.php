<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('settings')
            ->where('name', 'default_risk_score')
            ->update([
                'value' => '25'
            ]);
    }

    public function down(): void
    {
        DB::table('settings')
            ->where('name', 'default_risk_score')
            ->update([
                'value' => '10'
            ]);
    }
};
