<?php

namespace Database\Seeders;

use App\Models\PlanningStrategy;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TruncatePlanningStrategySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
   /**
     * Run the database seeds.
     * Truncates the planning_strategies table and inserts the 4 strategy options
     * that match the select options in the EditMitigation modal.
     */
    public function run(): void
    {
        // Truncate cleanly (disable FK checks to avoid constraint errors)
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        DB::table('planning_strategies')->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        $now = now();

        DB::table('planning_strategies')->insert([
            [
                'id'          => 1,
                'name'        => 'accepting',
            ],
            [
                'id'          => 2,
                'name'        => 'mitigating',
            ],
            [
                'id'          => 3,
                'name'        => 'sharing',
            ],
            [
                'id'          => 4,
                'name'        => 'avoiding',
            ],
        ]);

        $this->command->info('✅  PlanningStrategy table truncated and seeded with 4 records.');
    }
}
